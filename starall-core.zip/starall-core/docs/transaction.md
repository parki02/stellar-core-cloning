---
title: Transaction
---

- **Transaction**: Making a payment, creating an offer and so forth. Anything
  that changes a ledger's entries is called a transaction.

- **Transaction set**: Set of transactions that are applied to a ledger to
  produce the next one in the chain.

